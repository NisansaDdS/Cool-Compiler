/**
 * Created by Nisansa on 15/05/09.
 */
public class AdditionalSym {
    public static final int LIST = 501;
    public static final int METHOD_BLOCK = 502; //
    public static final int ID_TYPE = 503; //Checks the value of an ID (method, attribute)
    public static final int ITEMS = 504;
    public static final int ATTRIBUTE = 505; //
    public static final int INVOKE = 506;
}
